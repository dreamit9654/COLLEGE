dreamit10dashcamvlogs/
├── index.html
├── images/
│   ├── india1.jpg
│   └── ... etc
├── videos/
│   ├── india.mp4
│   └── ... etc
└── README.txt
